public interface Serializable {

}